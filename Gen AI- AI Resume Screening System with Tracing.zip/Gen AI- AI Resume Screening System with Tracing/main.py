import os
from dotenv import load_dotenv
from langchain_openai import ChatOpenAI

load_dotenv()

llm = ChatOpenAI(model="gpt-4o-mini")

def process_resume(resume, job_desc):

    extract_prompt = f"""
Extract skills, experience, and tools from this resume.
Do NOT assume anything.

Resume:
{resume}
"""
    extracted = llm.invoke(extract_prompt).content

    match_prompt = f"""
Compare resume with job description.

Return:
- matched skills
- missing skills

Resume Data:
{extracted}

Job Description:
{job_desc}
"""
    match = llm.invoke(match_prompt).content

    score_prompt = f"""
Give a score from 0 to 100 based on match quality.

Match Data:
{match}
"""
    score = llm.invoke(score_prompt).content

    explain_prompt = f"""
Explain why this score was given.

Score: {score}
Match Data: {match}
"""
    explanation = llm.invoke(explain_prompt).content

    return extracted, match, score, explanation


def main():
    with open("resumes.txt") as f:
        resumes = f.read().split("---")
    
    with open("job.txt") as f:
        job = f.read()

    for res in resumes:
        if res.strip() == "":
            continue

        print("\n========================")
        print(res.strip().split("\n")[0])

        extracted, match, score, explanation = process_resume(res, job)

        print("\nEXTRACTED:\n", extracted)
        print("\nMATCH:\n", match)
        print("\nSCORE:\n", score)
        print("\nEXPLANATION:\n", explanation)


if __name__ == "__main__":
    main()